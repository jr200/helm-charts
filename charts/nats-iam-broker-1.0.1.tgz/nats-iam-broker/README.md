# nats-iam-broker Helm Chart

A helm chart for deploying the nats-iam-broker application on kubernetes.

## Overview

This Helm chart installs the NATS IAM Broker, a native NATS decentralised auth-callout micro-service that manages identity and access for NATS deployments.

## Installation

To install the chart with the release name `my-iam-broker`:

```bash
helm repo add jr200 https://jr200.github.io/helm-charts/
helm install my-iam-broker jr200/nats-iam-broker
```

### Kubernetes Secrets

A set of credentials (secrets) must be mounted into the nats-iam-broker pod.
These credentials are:

- signing key for the MINT account
- user-creds for the MINT account's auth-callout user
- (optional) xkey for the auth-callout service to communicate with nats-server
- for each application account:
  - the public key
  - the signing key

Given a folder of secrets, the script below will create a K8s Secrets yaml in the expected format.

```
echo Creating kubernetes secrets...
curl  -fsSL https://raw.githubusercontent.com/jr200/nats-infra/refs/heads/main/scripts/k8s-make-nats-secrets.sh | bash -s -- <<secrets_folder>>
```

The generated `nats-secrets.yaml` can be uploaded to the nats-iam-broker target namespace.


## Configuration

The following table lists the configurable parameters of the `nats-iam-broker` chart and their default values.

| Parameter                                                 | Description                                                                               | Default                           |
| --------------------------------------------------------- | ----------------------------------------------------------------------------------------- | --------------------------------- |
| `devDebug`                                                | Enable or disable debug mode for development                                              | `false`                           |
| `replicaCount`                                            | Number of replicas for the deployment                                                     | `1`                               |
| `image.repository`                                        | The Docker image repository                                                               | `ghcr.io/jr200/nats-iam-broker`   |
| `image.pullPolicy`                                        | The image pull policy (Always, IfNotPresent, Never)                                       | `Always`                          |
| `image.tag`                                               | Overrides the image tag whose default is the chart appVersion                             | `""`                              |
| `imagePullSecrets`                                        | Docker registry secrets                                                                   | `[]`                              |
| `nameOverride`                                            | Override the default name of the chart                                                    | `""`                              |
| `fullnameOverride`                                        | Override the full name of the chart                                                       | `""`                              |
| `logging.json`                                            | Set to true to enable JSON logging                                                        | `false`                           |
| `logging.level`                                           | Set logging level (error, warn, info, debug, trace)                                       | `trace`                           |
| `env`                                                     | Environment variables for the nats-iam-broker container                                   | See values.yaml                   |
| `rbac.accounts`                                           | Configuration of decentralized accounts that can sign newly minted NATS user JWTs         | Example: see `values.yaml`        |
| `rbac.roles`                                              | Roles (groups of permissions + limits) that can be attached to minted NATS user JWTs      | Example: see `values.yaml`        |
| `rbac.bindings`                                           | Configuration to associate RBAC roles to RBAC accounts                                    | Example: see `values.yaml`        |
| `serviceAccount.create`                                   | Specifies whether a service account should be created                                     | `true`                            |
| `serviceAccount.automount`                                | Automatically mount a ServiceAccount's API credentials                                    | `true`                            |
| `serviceAccount.annotations`                              | Annotations to add to the service account                                                 | `{}`                              |
| `serviceAccount.name`                                     | The name of the service account to use.                                                   | `""`                              |
| `podAnnotations`                                          | Additional annotations to add to the pods                                                 | `{}`                              |
| `podLabels`                                               | Additional labels to add to the pods                                                      | `{}`                              |
| `podSecurityContext`                                      | Define security context for the pod                                                       | `{}`                              |
| `securityContext`                                         | Define security context for the container                                                 | `{}`                              |
| `resources`                                               | Resource requests and limits for the container                                            | `{}`                              |
| `volumes`                                                 | Additional volumes on the output Deployment definition                                    | `[]`                              |
| `volumeMounts`                                            | Additional volumeMounts on the output Deployment definition                               | `[]`                              |
| `nodeSelector`                                            | Node selector for pod scheduling                                                          | `{}`                              |
| `tolerations`                                             | Tolerations for pod scheduling                                                            | `[]`                              |
| `affinity`                                                | Affinity rules for pod scheduling                                                         | `{}`                              |
| `watch.enabled`                                           | Enable hot-reload of config files via file watching                                       | `false`                           |
| `metrics.enabled`                                         | Enable Prometheus metrics endpoint                                                        | `false`                           |
| `metrics.port`                                            | Port for the metrics HTTP server                                                          | `8080`                            |
| `metrics.serviceMonitor.enabled`                          | Create a Prometheus ServiceMonitor resource                                               | `false`                           |
| `metrics.serviceMonitor.interval`                         | Prometheus scrape interval                                                                | `30s`                             |
| `metrics.serviceMonitor.labels`                           | Additional labels for the ServiceMonitor                                                  | `{}`                              |

For a complete list of configuration options, see the `values.yaml` file.

## Health and Readiness Probes

When `metrics.enabled` is `true`, the broker exposes health endpoints on the metrics port. The Helm chart configures Kubernetes probes automatically:

| Probe     | Path       | Description                                                                                         |
| --------- | ---------- | --------------------------------------------------------------------------------------------------- |
| Liveness  | `/healthz` | Returns `200` if the process is alive and the NATS connection is active. Kubernetes restarts the pod on failure. |
| Readiness | `/readyz`  | Returns `200` when NATS is connected, at least one IDP verifier is ready, and the micro service endpoint is registered. Kubernetes removes the pod from service endpoints on failure. |

Both endpoints return JSON with a `status` field (`"ok"` or `"unavailable"`). The `/readyz` endpoint also includes a `checks` object with individual component status:

```json
{
  "status": "unavailable",
  "checks": {
    "nats": "disconnected",
    "idp_verifiers": "ready",
    "service": "registered"
  }
}
```

NATS disconnect/reconnect events automatically flip the readiness state, so a temporary NATS outage will remove the pod from service until the connection recovers.
